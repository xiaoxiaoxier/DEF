DEF<-function(countsTable,p="2/3"){
  cat("generalized log counts per million\n")
  b=colSums(countsTable)
  k=nchar(max(b))
  m=nrow(countsTable)
  n=ncol(countsTable)
  for(i in 1:m){for(j in 1:n) {countsTable[i,j]=log2(10^k*(countsTable[i,j]+1)/(b[j]+1))}}
  cat("differential entropy function\n")
  a=data.frame(countsTable)
  sum=rowSums(countsTable)
  for(i in 1:m){for(j in 1:n) {countsTable[i,j]=countsTable[i,j]/sum[i]}}
  for(i in 1:m){for(j in 1:n) {countsTable[i,j]=countsTable[i,j]*log(countsTable[i,j])}}
  A=rowSums(countsTable)
  entropy=A/log(n)+1
  entropy1=sort(entropy,decreasing=TRUE)
  entropygene=row.names(as.matrix(entropy1))
  cat("determine the threshold\n")
  
  dat = data.table(entropy) 
  dat = dat[,list(Freq = .N), by = entropy]
  dat = dat[,Total:= Freq/sum(Freq)][order(entropy,decreasing=T),]
  dat = dat[,S:=cumsum(Total),]
  s=dat$S
  i=1
  while((s[i]<p)==TRUE){i=i+1}
  g=i
  k=dat$entropy[i]
  
  cat("final differential expression genes\n")
  cat("DE_genes are saved in result, type result$DE_genes to see")
  #return(entropygene[1:mean(g)])
  result=list(DE_genes=entropygene[1:g])
              return(result)
  
}

  
