DEF<- function(a,p)
  {
  cat("Step 1: normalization (log-cpm)\n")
  a=a[rowSums(a)>0,]
  n=ncol(a)
  m=nrow(a)
  Y=colSums(a)
  k=floor(log10(max(Y)))+1
  a_cpm=a
  for (i in 1:m) {
    for (j in 1:n) {
      a_cpm[i,j]=log2(10^k*(a[i,j]+1)/Y[j]+1)
    }
  }
  
  cat("Step 2: DEF function to calculate entropy\n") 
  b=a_cpm
  
  Y=rowSums(b)
  for (i in 1:m) 
  {
    for (j in 1:n) 
    {b[i,j]=b[i,j]/Y[i]
    }
  }
  
  for(i in 1:m)
  {
    for(j in 1:n)
    {
      if(b[i,j]==0)
      {b[i,j]=0}
      else
      {b[i,j]=b[i,j]*log(b[i,j])}
    }
  }
  
  C=rowSums(b)
  entropy=1+C/log(n)
  entropy=sort(entropy,decreasing = TRUE)
  entropygene=row.names(as.matrix(entropy))
  
  
  cat("Step 3: determine the threshold\n") 
  dat=data.table(entropy)
  dat=dat[,list(Freq = .N),by= entropy]
  dat=dat[,Total:=Freq/sum(Freq)][order(entropy,decreasing = T),]
  dat=dat[,S:=cumsum(Total),]
  s=dat$S
  i=1
  while ((s[i]<p)==TRUE) {i=i+1}
    
  
  g=i
  k=dat$entropy[i]
  
  cat("final differential expression genes\n")
  cat("DE_genes are saved in result,type result$DE_genes to see")
  result=data.frame(DE_genes=entropygene[1:g],entropy=entropy[1:g])
  }

